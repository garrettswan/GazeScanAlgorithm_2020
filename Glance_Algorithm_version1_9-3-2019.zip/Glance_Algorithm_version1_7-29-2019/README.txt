README
Glance_Algorithm
- Contains the code for running the Glance Algorithm
Manual Marking
- Contains the code for manually marking gaze data
- Can use output generated from the Glance Algorithm, but it is not necessary

Both folders include some sample data called �sample_data.mat�
In order to load your own data into either the Glance Algorithm or Manual Marking, it should be a .mat file that has three variables
- x = gaze eccentricity in the x-dimension
- y = gaze eccentricity in the y-dimension
- t = time stamps


