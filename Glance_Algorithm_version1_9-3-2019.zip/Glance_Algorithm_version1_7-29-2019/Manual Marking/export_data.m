function export_data(handles)

%    This file is part of export_data.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with export_data.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019

try
    
    glance_count = 0;
    for i = 1:length(handles.theGlances)
        
        
        index = 0;
        
        output_temp1(1,1:8) = NaN;
        glance_count_temp = 1;
        
        for j = 1:length(handles.theGlances{i})
                if j == 1
                    
                    glance_count = glance_count + 1;
                    
                    index = index + 1;
                    glance_count_temp(index) = glance_count;
                    
                    output_temp1(index,1) = handles.theGlances{i}(j).starttime;
                    output_temp1(index,2) = handles.theGlances{i}(j).endtime;
                    output_temp1(index,3) = handles.theGlances{i}(j).glanceduration;
                    output_temp1(index,4) = handles.theGlances{i}(j).startX;
                    output_temp1(index,5) = handles.theGlances{i}(j).endX;
                    output_temp1(index,6) = handles.theGlances{i}(j).glancesize;
                    output_temp1(index,7) = handles.theGlances{i}(j).glance_marking;
                    output_temp1(index,8) = handles.theGlances{i}(j).marker;
                    
                else
                    if (handles.theGlances{i}(j).starttime ~= handles.theGlances{i}(j-1).starttime) && ...
                            (handles.theGlances{i}(j).endtime ~= handles.theGlances{i}(j-1).endtime)
                        
                        
                        glance_count = glance_count + 1;
                        
                        index = index + 1;
                        glance_count_temp(index) = glance_count;
                        
                        output_temp1(index,1) = handles.theGlances{i}(j).starttime;
                        output_temp1(index,2) = handles.theGlances{i}(j).endtime;
                        output_temp1(index,3) = handles.theGlances{i}(j).glanceduration;
                        output_temp1(index,4) = handles.theGlances{i}(j).startX;
                        output_temp1(index,5) = handles.theGlances{i}(j).endX;
                        output_temp1(index,6) = handles.theGlances{i}(j).glancesize;
                        output_temp1(index,7) = handles.theGlances{i}(j).glance_marking;
                        output_temp1(index,8) = handles.theGlances{i}(j).marker;
                        
                    end
                end
        end
        
        % now, making sure the order of the glances is by their time
        [temp, correct_order1] = sort(output_temp1(:,1));
        output_temp2(glance_count_temp,:) = output_temp1(correct_order1,:);
       
        % don't always have the same number of these
        clear glance_count_temp output_temp1
    end
    
    % now, making sure the order of the events is correct
    [temp, correct_order2] = sort(output_temp2(:,1),'Ascend');
    
    output = output_temp2(correct_order2,:);
    
    % this is just a check that are ordering is correct
    % if n start time is greater than n+1 start time (i.e. if the next glance
    % starts earlier than the previous glance) more than the number of glances
    % (because the order is descending), then one of the sorting went wrong
    if sum(output(1:(end)-1,3) > output(2:end,3)) > length(handles.theGlances{1})
        disp('***********ERROR************');
        disp(' ');
        disp('Something maybe went wrong with the ordering. Double check your data!!');
        disp(' ');
        disp('***********ERROR************');
    end
    
   % a = num2cell(output);
    c = {'start_time' 'end_time' 'duration' ...
        'start_ecc' 'end_ecc' 'magnitude'  ...
        'glance_marking' 'marking'};
    
    tbl = table(output(:,1),output(:,2),output(:,3),output(:,4),output(:,5),output(:,6),output(:,7),output(:,8),'VariableNames',c);
    
    try
        writetable(tbl,[handles.pathname handles.filename_no_format '_' handles.foldername handles.filename_no_format '.xlsx']);
    catch
        writetable(tbl,[handles.pathname handles.filename_no_format '_' handles.foldername handles.filename_no_format '.csv'])    
    end
    
%     formatSpec = '%2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.0f\n';
%     fid = fopen([handles.pathname handles.filename_no_format '_' handles.foldername handles.filename_no_format '.xlsx'], 'w') ;
%     fprintf(fid, '%s, %s, %s, %s, %s, %s, %s, ', c{1,1:end-1}) ;
%     fprintf(fid, '%s\n', c{1,end}) ;
%     
%     [nrows,ncols] = size(a);
%     for row = 1:nrows
%         fprintf(fid,formatSpec,a{row,:});
%     end
%     
%     fclose(fid);
%     
    %  csvwrite([handles.pathname handles.foldername handles.filename(1:39) '.csv'],output)
    
catch
    keyboard
end

end