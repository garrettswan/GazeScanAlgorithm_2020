function theGlances = get_data_from_figure(ax)

%    This file is part of get_data_from_figure.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with get_data_from_figure.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019

marked_glance = 0;
count = 0;
for i = (size(ax.Children,1)):-1:1
    if strcmpi(ax.Children(i).Type,'line')
        if strcmp(ax.Children(i).Visible,'on') && sum(ax.Children(i).LineWidth == 4)
            count = count + 1;
            marked_glance(count) = i;
        end
    end
end

number_glances = count;

if number_glances > 0
    for i = 1:length(marked_glance)
        glance_info = ax.Children(marked_glance(i));
        
        times_temp = [glance_info.XData(1:2)];
        % then, we need to make sure the index is the same for
        % the eccentricity
        ecc_temp = [glance_info.YData(1:2)];
        
        [min_times_temp, min_index] = min(times_temp);
        
        theGlances(i).endtime =  max(times_temp);
        theGlances(i).starttime = min_times_temp;
        theGlances(i).glanceduration = theGlances(i).endtime-theGlances(i).starttime;
        
        theGlances(i).endX = ecc_temp(mod(min_index,2)+1);
        theGlances(i).startX = ecc_temp(min_index);
        theGlances(i).glancesize = theGlances(i).endX-theGlances(i).startX;
        
        if strcmpi(glance_info.LineStyle,'-')
            theGlances(i).glance_marking = 1;
        else
            theGlances(i).glance_marking = 0;
        end
            
        colors = [0 1 0; 1 0 0; .8 .75 0; 1 .5 0; .6 .25 .6; .25 .7 1];
        
        if glance_info.Color == [0 1 0]
            theGlances(i).marker = 1;
        elseif glance_info.Color == [1 0 0]
            theGlances(i).marker = 2;
        elseif glance_info.Color == [.8 .75 0]
            theGlances(i).marker = 3;
        elseif glance_info.Color == [1 .5 0]
            theGlances(i).marker = 4;
        elseif glance_info.Color ==  [.6 .25 .6]
            theGlances(i).marker = 5;
        elseif glance_info.Color == [.25 .7 1]
            theGlances(i).marker = 6;
        else
            theGlances(i).marker = NaN;
        end
        
        %         theGlances(i).endtime = glance_info.XData(1);
        %         theGlances(i).starttime = glance_info.XData(2);
        %         theGlances(i).glanceduration = glance_info.XData(1)-glance_info.XData(2);
        %
        %         theGlances(i).endX = glance_info.YData(1);
        %         theGlances(i).startX = glance_info.YData(2);
        %         theGlances(i).glancesize = abs(glance_info.YData(1)-glance_info.YData(2));
        
        
        
    end
else
    
    
    theGlances(i).endtime = NaN;
    theGlances(i).starttime = NaN;
    theGlances(i).glanceduration = NaN;
    
    theGlances(i).endX = NaN;
    theGlances(i).startX = NaN;
    theGlances(i).glancesize = NaN;

    theGlances(i).marker = NaN;
    
    theGlances(i).glance_marking = NaN;
    
end

end