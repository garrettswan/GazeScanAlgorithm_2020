function varargout = Manual_Marking(varargin)
% MANUAL_MARKING MATLAB code for Manual_Marking.fig
%      MANUAL_MARKING, by itself, creates a new MANUAL_MARKING or raises the existing
%      singleton*.
%
%      H = MANUAL_MARKING returns the handle to a new MANUAL_MARKING or the handle to
%      the existing singleton*.
%
%      MANUAL_MARKING('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MANUAL_MARKING.M with the given input arguments.
%
%      MANUAL_MARKING('Property','Value',...) creates a new MANUAL_MARKING or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Manual_Marking_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Manual_Marking_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Manual_Marking

% Last Modified by GUIDE v2.5 25-Jul-2019 11:24:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Manual_Marking_OpeningFcn, ...
    'gui_OutputFcn',  @Manual_Marking_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Manual_Marking is made visible.
function Manual_Marking_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Manual_Marking (see VARARGIN)

% Choose default command line output for Manual_Marking
handles.output = hObject;

% UIWAIT makes Manual_Marking wait for user response (see UIRESUME)
% uiwait(handles.figure1);

set( findall( gcf, '-property', 'Units' ), 'Units', 'Normalized' );

% initializing some variables
handles.current_event = 0;
handles.accessing_folder = 0;
handles.filename = 0;
handles.theGlances{1} = [];
handles.total_events = 999;
handles.pathname = 0;
handles.end_early = 0;
handles.delete_times = [NaN NaN];

% this variable will determine what the eventual pathname will be for this
% run of the manual algorithm
clocktime = clock;

if IsOSX
    handles.foldername = [num2str(clocktime(2)) '_' num2str(clocktime(3)) '_' num2str(clocktime(4)) num2str(clocktime(5)) '/'];
else
    handles.foldername = [num2str(clocktime(2)) '_' num2str(clocktime(3)) '_' num2str(clocktime(4)) num2str(clocktime(5)) '\'];
end

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = Manual_Marking_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% this push button places the markings

ax = gca;

acceptable_markings = 0;
count = 0;
for i = (length(ax.Children)-1):-1:1
    if strcmp(ax.Children(i).Visible,'on') && strcmp(ax.Children(i).Marker,'+')
        
        % here, we are trying to find the correct child (i.e. one with our
        % markings)
        count = count + 1;
        acceptable_markings(count) = i;
        
    end
end

if count > 1 || sum([get(handles.checkbox10,'Value') get(handles.checkbox11,'Value')]) == 1
    
    % if we have some markings that we made, take them, and then plot them
    first_marking = ax.Children(acceptable_markings(end));
    
    starttime = first_marking.XData;
    
    if count > 1
        second_marking = ax.Children(acceptable_markings(end-1));
        endtime = second_marking.XData;
        startX = first_marking.YData;
        endX = second_marking.YData;
    end
    
    whichcolor = [get(handles.checkbox3,'Value') get(handles.checkbox5,'Value') ...
        get(handles.checkbox6,'Value') get(handles.checkbox7,'Value') get(handles.checkbox8,'Value') ...
        get(handles.checkbox9,'Value') get(handles.checkbox10,'Value') get(handles.checkbox11,'Value')];
    
    colors = [0 1 0; 1 0 0; .8 .75 0; 1 .5 0; .6 .25 .6; .25 .7 1; 0.01 0.01 0.01; 0.02 0.02 0.02];
    
    if find(whichcolor)==7 | find(whichcolor)==8
        line([starttime starttime],[-90 90],'Color',colors(whichcolor==1,:),'LineWidth',2,'LineStyle',':');
    else
        line([starttime endtime],[startX endX],'Color',colors(whichcolor==1,:),'LineWidth',4,'LineStyle',':');
    end
end

% Update handles structure
guidata(hObject, handles);



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% this pushbutton undos any of the previously visible markings. Visibility
% is important because only visible information is included

ax = gca;

for i = (length(ax.Children)):-1:1
    if strcmp(ax.Children(i).Visible,'on')
        first_marking = ax.Children(i);
    end
end

set(first_marking,'Visible','off')

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% we've hit the finished/next button

ax = gca;

% just a check that prevents premature submission. Occasionally, in the
% flow, it is easy to want to continue without submitting the last glance.
% This is just a check that prevents that
go_on = 1;
if strcmp(ax.Children(1).Visible,'on') && strcmp(ax.Children(1).Marker,'+') && ...
        strcmp(ax.Children(2).Visible,'on') && strcmp(ax.Children(2).Marker,'+')
    go_on = 0;
end

if go_on
    set(handles.pushbutton5,'String','Finish/Next');
    set(handles.pushbutton5,'ForegroundColor','k');
    
    % check the checkboxes to see what we want to save
    save_output = get(handles.checkbox1,'Value');
    save_figure = get(handles.checkbox2,'Value');
    
    % now, we will create a directory if it does not exist
    % this is to prevent overwriting existing data
    if save_output || save_figure
        if exist([handles.pathname handles.filename_no_format '_' handles.foldername]) ~= 7
            mkdir([handles.pathname handles.filename_no_format '_' handles.foldername]);
        end
    end
    
    % get the glances from the figure
    theGlances = get_data_from_figure(ax);
    handles.theGlances{handles.current_event} = theGlances;
    
    
    % save the glance output
    if save_output
        export_data(handles);
    end
    
    % save the figure
    if save_figure
        
        ax = gca;
        
        start_time = (ax.Children(end-3).XData(1));
        start_index = 1;
        good_to_go = 0;
        plot_count = 0;
        while good_to_go == 0
            
            [~,end_index] = min(abs((ax.Children(end-3).XData-start_time)-15));
            
            end_time = (ax.Children(end-3).XData(end_index));
            
            h = figure;
            hold on
            
            plot(ax.Children(end-3).XData(start_index:end_index),ax.Children(end-3).YData(start_index:end_index),'b','LineWidth',3);
            line([min(ax.Children(end-3).XData(start_index:end_index)) max(ax.Children(end-3).XData(start_index:end_index))],[0 0]);
            set(gca, 'Ydir', 'reverse');
            ylabel('Eccentricity (\circ)')
            xlabel('Time (s)')
            ylim([-90 90])
            xlim([start_time start_time+15])
            
            for iGlance = 1:length(theGlances)
                
                if theGlances(iGlance).starttime >  start_time && theGlances(iGlance).endtime < end_time
                    if theGlances(iGlance).glance_marking
                        colorCode = [0 1 0];
                        
                        
                        plot([theGlances(iGlance).starttime theGlances(iGlance).endtime], ...
                            [theGlances(iGlance).startX theGlances(iGlance).endX],...
                            'Color',colorCode, 'LineStyle','-','Marker','none','LineWidth',4);
                        
                    else
                        colors = [0 1 0; 1 0 0; .8 .75 0; 1 .5 0; .6 .25 .6; .25 .7 1; 0.01 0.01 0.01; 0.02 0.02 0.02];
                        plot([theGlances(iGlance).starttime theGlances(iGlance).endtime], ...
                            [theGlances(iGlance).startX theGlances(iGlance).endX],...
                            'Color',colors(theGlances(iGlance).marker,:), 'LineStyle',':','Marker','none','LineWidth',4);
                        
                    end
                end
                
            end
            
            plot_count = plot_count + 1;
            
            printpath = [handles.pathname handles.filename_no_format '_' handles.foldername handles.filename];
            printpath(findstr(printpath,'.mat'):end) = [];
            print(h,[printpath '_' num2str(plot_count)],'-dmeta')
            
            if end_index == length(ax.Children(end-3).XData)
                good_to_go = 1;
            else
                start_time = end_time;
                start_index = end_index;
            end
            
            close(h)
        end
        
    end
    
    % close gui
    close(handles.figure1)
    %  end
    
else
    set(handles.pushbutton5,'String','CHECK MARKINGS');
    set(handles.pushbutton5,'ForegroundColor','r');
end



% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1

% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3

if get(handles.checkbox3,'Value') ==1
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5

if get(handles.checkbox5,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6

if get(handles.checkbox6,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7

if get(handles.checkbox7,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8

if get(handles.checkbox8,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9

if get(handles.checkbox9,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox10,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10

if get(handles.checkbox10,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox11,'Value',0)
end

% --- Executes on button press in checkbox11.
function checkbox11_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox11

if get(handles.checkbox11,'Value') ==1
    set(handles.checkbox3,'Value',0)
    set(handles.checkbox5,'Value',0)
    set(handles.checkbox6,'Value',0)
    set(handles.checkbox7,'Value',0)
    set(handles.checkbox8,'Value',0)
    set(handles.checkbox9,'Value',0)
    set(handles.checkbox10,'Value',0)
end

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

ax = gca;

for i = 1:size(ax.Children,1)
    if strcmpi(ax.Children(i).Type,'line')
        
        if sum(ax.Children(i).Color == [0.0100 0.0100 0.0100])==3
            handles.delete_times(1) = mean(ax.Children(i).XData);
        end
        
        if sum(ax.Children(i).Color == [.02 .02 .02])==3
            
            handles.delete_times(2) = mean(ax.Children(i).XData);
        end
    end
end

%cla

% here, display the glance information in the gui
t = plot_gaze(handles);

[~,fuu] = min(abs((t(1)+15)-t));

set(gca,'Xlim',[t(1) t(fuu)])

set(handles.slider1,'Value',t(fuu))
set(handles.slider1,'Min',t(fuu));
set(handles.slider1,'Max',t(end));
set(handles.slider1,'Visible','on');

handles.t = t;


% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cla(handles.axes1,'reset')

% set(handles.pushbutton4,'Visible','off');
% set(handles.pushbutton3,'Visible','off');

% get the file we want to load
[filename pathname] = uigetfile('.mat');

handles.current_event = handles.current_event + 1;
handles.filename = filename;
handles.pathname = pathname;

dot_index = findstr(handles.filename,'.');
handles.filename_no_format = handles.filename(1:(dot_index-1));

% here, we are just changing the string at the bottom of the figure
set(handles.text2,'String',handles.filename_no_format)

% here, display the glance information in the gui
t = plot_gaze(handles);

[~,fuu] = min(abs((t(1)+15)-t));

set(gca,'Xlim',[t(1) t(fuu)])

set(handles.slider1,'Value',t(fuu))
set(handles.slider1,'Min',t(fuu));
set(handles.slider1,'Max',t(end));
set(handles.slider1,'Visible','on');

handles.t = t;

% Update handles structure
guidata(hObject, handles);



% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

slider1_val = get(handles.slider1,'Value');

[~,fuu2] = min(abs(slider1_val-handles.t));
[~,fuu1] = min(abs((slider1_val-15)-handles.t));

set(gca,'Xlim',[handles.t(fuu1) handles.t(fuu2)])

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
