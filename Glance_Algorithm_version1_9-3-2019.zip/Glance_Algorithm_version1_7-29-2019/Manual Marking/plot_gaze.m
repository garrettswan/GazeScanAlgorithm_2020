function [t] = plot_gaze(handles)

%    This file is part of plot_gaze.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with plot_gaze.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019


if sum(isnan(handles.delete_times))==0

    ax = gca;
    
    theGlances = get_data_from_figure(ax);
    
    count = 0;
    for i = 1:size(theGlances,2)
    
       if (theGlances(i).starttime < handles.delete_times(1) && theGlances(i).endtime > handles.delete_times(1)) ...
               || (theGlances(i).starttime > handles.delete_times(1) && theGlances(i).endtime < handles.delete_times(2)) ...
               || (theGlances(i).starttime < handles.delete_times(2) && theGlances(i).endtime > handles.delete_times(2))
          
           count = count + 1;
           glances_to_delete(count) = i; 
           
       end
    end
    
    theGlances(glances_to_delete) = [];
    
    cla
    
end


load([handles.pathname handles.filename]);

theTimes = t;

line([min(theTimes) max(theTimes)],[0 0]);
hold on

line([min(theTimes) min(theTimes)],[-100 100],'Color','k');
line([max(theTimes) max(theTimes)],[-100 100],'Color','k');

plot(theTimes,x,'b','LineWidth',3);

set(gca, 'Ydir', 'reverse');
xlim([min(theTimes) max(theTimes)]);


if exist([handles.pathname handles.filename_no_format '.xlsx']) ==2 && ~sum(isnan(handles.delete_times))==0
    
    tbl = readtable([handles.pathname handles.filename_no_format '.xlsx']);
    
    for iGlance = 1:size(tbl,1)
        
        if tbl.glance_marking(iGlance)
            
            colorCode = [0 1 0];
            plot([tbl.start_time(iGlance) tbl.end_time(iGlance)], ...
                [tbl.start_ecc(iGlance) tbl.end_ecc(iGlance)],...
                'Color',colorCode, 'LineStyle','-','Marker','none','LineWidth',4);
            
        else
            
            colorCode = [0 1 0; 1 0 0; .8 .75 0; 1 .5 0; .6 .25 .6; .25 .7 1; 0.01 0.01 0.01; 0.02 0.02 0.02];
            plot([tbl.start_time(iGlance) tbl.end_time(iGlance)], ...
                [tbl.start_ecc(iGlance) tbl.end_ecc(iGlance)],...
                'Color',colorCode(tbl.marking(iGlance),:), 'LineStyle',':','Marker','none','LineWidth',4);
            
        end
    end
    
end

if sum(isnan(handles.delete_times))==0
    
   for iGlance = 1:length(theGlances)

       if theGlances(iGlance).glance_marking
           colorCode = [0 1 0];
           
           
           plot([theGlances(iGlance).starttime theGlances(iGlance).endtime], ...
               [theGlances(iGlance).startX theGlances(iGlance).endX],...
               'Color',colorCode, 'LineStyle','-','Marker','none','LineWidth',4);
           
       else
           colors = [0 1 0; 1 0 0; .8 .75 0; 1 .5 0; .6 .25 .6; .25 .7 1; 0.01 0.01 0.01; 0.02 0.02 0.02];
           plot([theGlances(iGlance).starttime theGlances(iGlance).endtime], ...
               [theGlances(iGlance).startX theGlances(iGlance).endX],...
               'Color',colors(theGlances(iGlance).marker,:), 'LineStyle',':','Marker','none','LineWidth',4);
           
       end
        
        
    end
    
end


ylabel('Eccentricity (\circ)')
xlabel('Time (s)')

ylim([-90 90])

% now attach the function to the axes
set(gca,'ButtonDownFcn', @mouseclick_callback);

% and we also have to attach the function to the children, in this
% case that is the line in the axes.
set(get(gca,'Children'),'ButtonDownFcn', @mouseclick_callback);

end

