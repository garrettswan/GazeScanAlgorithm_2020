function mouseclick_callback(gcbo,eventdata)

% the arguments are not important here, they are simply required for
% a callback function. we don't even use them in the function,
% but Matlab will provide them to our function, we we have to
% include them.
%
% first we get the point that was clicked on
cP = get(gca,'Currentpoint');
x = cP(1,1);
y = cP(1,2);
% % Now we find out which mouse button was clicked, and whether a
% % keyboard modifier was used, e.g. shift or ctrl
%  switch get(gcf,'SelectionType')
%      case 'normal' % Click left mouse button.
%      case 'alt'    % Control - click left mouse button or click right mouse button.
%      case 'extend' % Shift - click left mouse button or click both left and right mouse buttons.
%      case 'open'   % Double-click any mouse button.
%  end

cursor_handle = plot(0,0,'r+ ','visible','off');
set(cursor_handle,'Xdata',x,'Ydata',y,'visible','on')
set(cursor_handle,'ButtonDownFcn',@mouseclick_callback);


end
