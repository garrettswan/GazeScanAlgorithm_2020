README

If utilizing this code, please reference: Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye and Head Movements to Quantify Gaze Scanning Behaviors in a Driving Simulator 

Glance Algorithm
- Algorithm that automatically detects large horizontal eye and head (i.e. gaze) movements

How to run the algorithm
- Open Matlab
- Type "Glance_Algorithm_GUI" into the command window
- You will be presented with parameters on the left and a couple of options on the right
	- Data smoothing parameters for SGO filtering of the gaze data
		- Filter order = fixed at 3
		- Filter length = fixed at 7
	- Gaze saccade detection parameters used to detect gaze saccade (i.e. similar to eye-only saccades)
		- Velocity threshold = fixed at 30 degrees per second
		- Size threshold = fixed at 1 degree to remove saccades smaller than 1 degree magnitude
		- Duration threshold = fixed at .033 seconds to remove saccades shorter than .033 seconds in duration
	- Merging gaze saccades together
		- Pause length = set to .400 seconds based on the best fit to testing data
	- Filename
		- Enter the filename for your .mat file. The .mat should contain x = gaze x position in degrees, y = gaze y position in degrees, and t = time in seconds
	- Plot data
		- Plots the data with the glance algorithm marked gaze scans for the entire data set
	- Save data
		- Saves data as an excel file that can be used by the Manual Marking code or for data analysis in Matlab/other software
	- Run Glance Algorithm
		- Clicking this button will run the algorithm

 Troubleshooting
- Check that the format of your data is in the same format as the sample_data.mat file
- The Glance_Algorithm.m is the primary function. It loads the data specificed in the gui, then filters it, then calls Gaze_saccade_categorization.m to find the gaze saccades, then called Merging_gaze_saccades to merge the found gaze saccades, and then plots and/or saves the data based on selections made in the GUI 

Advice
- The current code could be used straight away with any data set, provided the format is the same. Alternatively, one could edit the Glance_algorithm.m file such that you pass in your own data, then output the gaze scans generated from the glance algorithm. 

For questions or comments, please contact Garrett Swan at gsp.swan at gmail.com