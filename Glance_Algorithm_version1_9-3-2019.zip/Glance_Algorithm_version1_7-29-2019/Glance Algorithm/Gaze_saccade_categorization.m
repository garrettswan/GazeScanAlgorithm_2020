function [gaze_movements] = Gaze_saccade_categorization(smoothHor,smoothVer,time,parameters)

%    This file is part of Gaze_saccade_categorization.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Gaze_saccade_categorization.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019

% just renaming things
gazeX = smoothHor;
gazeY = smoothVer;

glance_count = 0;

% initiallizing the type array as all Ns
type = char(zeros(1,length(gazeX))+78);

% we find the saccades

% start by finding everything not marked as fixations
sac_or_pur = find(type=='N');
sac_or_pur_index = zeros(1,length(sac_or_pur));

for i = 1:length(sac_or_pur)
    
    if sac_or_pur_index(i) == 0
        
        % here, we are trying to look at chunks of Ns
        temp_sac_or_pur = sac_or_pur(~sac_or_pur_index);
        
        start_index = sac_or_pur(i);
        end_index = temp_sac_or_pur(min(find(diff(temp_sac_or_pur)>1)));
        
        if isempty(end_index)
            % must mean we are at the last saccade
            end_index = temp_sac_or_pur(end);
        end
        
        % pull out the specific index of our chunk
        sac_or_pur_index(find(sac_or_pur==start_index):find(sac_or_pur==end_index)) = 1;
        
        % calculate velocity
        temp_gazeX = gazeX(start_index:end_index);
        temp_gazeY = gazeY(start_index:end_index);
        temp_time = time(start_index:end_index);
        
        velocity = sqrt((diff(temp_gazeY).^2)+(diff(temp_gazeX).^2))./diff(temp_time);
        velocity = velocity .* sign(diff(temp_gazeX)./diff(temp_time));
        
        for j = 1:length(velocity)
            
            % if we are above the threshold but the velocity is on the
            % right, then these must be right saccades
            if sign(velocity(j))==1 && abs(velocity(j)) > parameters(4)
                
                type(temp_sac_or_pur(j)) = 'R';
                type(temp_sac_or_pur(j+1)) = 'R';

                % if we are above the threshold but the velocity is on the
                % right, then these must be left saccades
            elseif sign(velocity(j))==-1 && abs(velocity(j)) > parameters(4)
                
                type(temp_sac_or_pur(j)) = 'L';
                type(temp_sac_or_pur(j+1)) = 'L';
               
                % if we are don't cross the threshold, then we don't have a
                % saccade
            else
                type(temp_sac_or_pur(j)) = 'N';
                type(temp_sac_or_pur(j+1)) = 'N';
            end
        end
    end
end

% At this point, we have F and S and not-defined events. So, the next step
% is to bundle F, S, and N into discrete sequences

glance_count = 0;

prev_type = type(1);
count = 1;
index(count) = 1;
for i = 2:length(gazeX)
    
    % if the current type is the same as the previous type, keep adding the
    % index to the list
    if type(i)==prev_type && i < length(gazeX)
        count = count + 1;
        index(count) = i;
        
    else
        
        % this is important
        % now, we append the NEXT data point to the previous sequence. So,
        % if we had an F followed by an S, the first data point of the S
        % would then be attached to the end of the F.
        %
        % this is really important to prevent cases where a sequence is
        % made up of only a single data point, which aint good?
        
        count = count + 1;
        index(count) = i;
        
        glance_count = glance_count + 1;
        
        gaze_movements(glance_count).gaze = gazeX(index)';
        gaze_movements(glance_count).time = time(index)';
        gaze_movements(glance_count).gazeY = gazeY(index)';
                
        % change the classification to be the correct case
        if prev_type == 'L'
            gaze_movements(glance_count).type = 's';
        elseif prev_type == 'R'
            gaze_movements(glance_count).type = 's';
        elseif prev_type == 'N'
            gaze_movements(glance_count).type = 'N';
        elseif prev_type == 'f'
            gaze_movements(glance_count).type = 'f';
        elseif prev_type == 'F'
            gaze_movements(glance_count).type = 'f';
        end
        
        if strcmpi(gaze_movements(glance_count).type,'s')
            
            if length(gaze_movements(glance_count).time) <= parameters(3)
                gaze_movements(glance_count).type = 'N';
            end
                            
            if range(gaze_movements(glance_count).gaze([1 end])) <  parameters(5)    
                
                gaze_movements(glance_count).type = 'N';
            end
        end
        
        prev_type = type(i);
        
        count = 1;
        clear index
        index(count) = i;
        
    end
end


% sometimes, our samples cross zero
% that isn't good, so we must split those glances

before_splitting_glances = gaze_movements;
clear glances
count = 0;
for i = 1:size(before_splitting_glances,2)
    
    % get current data
    current_gaze = before_splitting_glances(i).gaze;
    current_time = before_splitting_glances(i).time;
    current_type = before_splitting_glances(i).type;
    current_gazeY = before_splitting_glances(i).gazeY;
        
    if length(current_gaze) ==1
        P = [];
    else
        % find intersection with 0
        P = InterX([current_time;current_gaze],[current_time;zeros(1,length(current_time))]);
    end
    
    % if there is no intersection, then just add the glance to the list
    if isempty(P)
        count = count + 1;
        
        gaze_movements(count).gaze = current_gaze;
        gaze_movements(count).time = current_time;
        gaze_movements(count).type = current_type;
        gaze_movements(count).gazeY = current_gazeY;
        
        nanindex = isnan(gaze_movements(count).gaze);
        
        % here, we are just trying to figure out what side its on
        if length(unique(sign(gaze_movements(count).gaze(~nanindex)))) > 1
            % more than one sign? huh?
            keyboard
        else
            % if they are all negative, then the side is left (-1)
            % if they are all positive, then the side is right (1)
            gaze_movements(count).side = unique(sign(gaze_movements(count).gaze(~nanindex)));
        end
        
        gaze_movements(count).crossover = 0;
    else
        
        % now, we need to figure out how many times we cross zero, which
        % may happen since this is each data point and not just a line
        for j = 1:(size(P,2)+1)
            
            % we need to figure out the gaze/time for each cross over and
            % also keep a list of what we will be adding
            if j == 1
                idx = current_time < P(1,j) & current_time >= current_time(1);
                add_glance_time = P(1,j);
                % note: why .00001? this is necessary because we want all of the gaze
                % to be on one side and if I set this to 0, 0 ain't on a
                % side
                add_glance_gaze = 0.0001*unique(sign(current_gaze(idx)));
                
            elseif j == (size(P,2)+1)
                idx = current_time <= current_time(end) & current_time >= P(1,j-1);
                add_glance_time = P(1,j-1);
                add_glance_gaze = 0.0001*unique(sign(current_gaze(idx)));
                
            else
                % because this is a middle case, we have two things to add
                idx = current_time < P(1,j) & current_time >= P(1,j-1);
                add_glance_time = [P(1,j-1) P(1,j)];
                add_glance_gaze = [0.0001*unique(sign(current_gaze(idx))) ...
                    0.0001*unique(sign(current_gaze(idx)))];
                
            end
            
            count = count + 1;
            
            % add the new markings
            temp_time = [current_time(idx) add_glance_time];
            temp_gaze = [current_gaze(idx) add_glance_gaze];
            
            % before adding the new markings, we need to find the
            % corresponding crossing points for the Y dimension
            %
            % So, we use the time found above, draw a straight line with
            % the new time, then find the intersection to see how we chop
            % up the y-dimensions (since the y-dimension doesn't
            % necessarily cross 0)
            if length(add_glance_time) == 1
                
                P2 = InterX([current_time;current_gazeY],[add_glance_time add_glance_time; min(current_gazeY) max(current_gazeY)]);
                temp_gazeY = [current_gazeY(idx) P2(2,1)];

            else
                % we have to do this if we have two cross over points
                for k = 1:length(add_glance_time)
                    P2 = InterX([current_time;current_gazeY],[add_glance_time(k) add_glance_time(k); min(current_gazeY) max(current_gazeY)]);
                    add_glance_gazeY(k) = P2(2,1);
                end
                temp_gazeY = [current_gazeY(idx) add_glance_gazeY];
                
            end
            
            if isempty(P2)
                error('empty p2? What?! No way!');
            end
            
            % now, we need to make sure things are added in the correct
            % order
            [~,ord_idx] = sort([current_time(idx) add_glance_time]);
            
            gaze_movements(count).gaze = temp_gaze(ord_idx);
            gaze_movements(count).time = temp_time(ord_idx);
            gaze_movements(count).gazeY = temp_gazeY(ord_idx);
                                    
            % create temp variables
            temp_temp_gaze = temp_gaze(ord_idx);
            temp_temp_time = temp_time(ord_idx);
            temp_temp_gazeY = temp_gazeY(ord_idx);
                        
            if j == (size(P,2)+1) && current_type ~= 'f'
                % need to remove the last data point if this is the end of the original sequence, since the last data point
                % is the first data point from the next sequence and doesn't
                % necessarily follow the rules
                temp_temp_gaze(end) = [];
                temp_temp_time(end) = [];
                temp_temp_gazeY(end) = [];
            end
            
            % initialize the type as N
            gaze_movements(count).type = 'N';
            
            % now, using the same parameters as before, does the new F or S
            % meet the requirements of an F and S
            if current_type == 's'
                
                velocity = sqrt((diff(temp_temp_gazeY).^2)+(diff(temp_temp_gaze).^2))./diff(temp_temp_time);
                velocity = velocity .* sign(diff(temp_temp_gaze)./diff(temp_temp_time));
                
                if ~any(abs(velocity) < parameters(4))
                    gaze_movements(count).type = 's';
                end
                
                if length(temp_temp_time) <= parameters(3)  
                    gaze_movements(count).type = 'N';
                end
                
               % if sqrt((diff(temp_temp_gaze([1 end])).^2)+(diff(temp_temp_gazeY([1 end])).^2)) <  parameters(5)
                
                if range(temp_temp_gaze([1 end])) <  parameters(5)    
                    gaze_movements(count).type = 'N';
                end
                
            end
            
            if length(unique(sign(gaze_movements(count).gaze))) > 1
                disp('more than one sign? Huh?');
                gaze_movements(count).side = unique(sign(nanmean(gaze_movements(count).gaze)));
            else
                % if they are all negative, then the side is left (-1)
                % if they are all positive, then the side is right (1)
                gaze_movements(count).side = unique(sign(gaze_movements(count).gaze));
            end
            
            gaze_movements(count).crossover = 1;
        end
    end
    
    % have to use current type! we are using this to help with saccade's
    % crossing zero and because saccades crossing zero overlap with
    % previous fixations, then we need to know if our previous thing was a
    % fixation. Problem is, a fixation could then not a fixation. So, we
    % have to use the current, unchanged, one
    prev_type = current_type;
    
end



end

