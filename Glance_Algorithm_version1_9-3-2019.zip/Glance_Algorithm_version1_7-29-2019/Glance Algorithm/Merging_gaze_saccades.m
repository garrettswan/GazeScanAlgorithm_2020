function [gaze_scans] = Merging_gaze_saccades(gaze_movements,parameters)

%    This file is part of Merging_gaze_saccades.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Merging_gaze_saccades.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019

count = 0;
for i = 1:length(gaze_movements)
    if strcmpi(gaze_movements(i).type,'s')
        count = count + 1;
        new_gaze_scans(count) = gaze_movements(i);
    end
end

%new_glances = glances;

good_to_go_count = 0;
loop_count = 0;

% sometimes, when finding the rate of things, there is a repeated time? So,
% this is just a little bump that helps things out
offset = [0 .0001];

while good_to_go_count < 6 && loop_count < 10
    loop_count = loop_count + 1;
    
    num_scans = length(new_gaze_scans);
    glancesBeforeMergeAdjacentScans = new_gaze_scans;
    
    prior_gaze = glancesBeforeMergeAdjacentScans(1).gaze;
    prior_time = glancesBeforeMergeAdjacentScans(1).time;
    prior_side = glancesBeforeMergeAdjacentScans(1).side;
    prior_type = glancesBeforeMergeAdjacentScans(1).type;
    
    clear new_gaze_scans start_times end_times start_gaze end_gaze rate side
    
    new_gaze_scans(1).gaze = prior_gaze;
    new_gaze_scans(1).time = prior_time;
    new_gaze_scans(1).side = prior_side;
    new_gaze_scans(1).type = prior_type;
    
    new_scan_count = 1;

    prior_rate = (prior_gaze(end)-prior_gaze(1))/(prior_time(end)-prior_time(1));
    
    start_times(new_scan_count) = prior_time(1);
    end_times(new_scan_count) = prior_time(end);
    
    start_gaze(new_scan_count) = prior_gaze(1);
    end_gaze(new_scan_count) = prior_gaze(end);
    
    rate(new_scan_count) = prior_rate;
    
    nanindex = isnan(prior_gaze);
    
    if sum(nanindex)==length(nanindex)
        side(new_scan_count) = NaN;
    else
        side(new_scan_count) = unique(sign(prior_gaze(~nanindex)));
    end
    
    type(new_scan_count) = prior_type;
    
    for iScan = 2:num_scans
        
        current_gaze = glancesBeforeMergeAdjacentScans(iScan).gaze;
        current_time = glancesBeforeMergeAdjacentScans(iScan).time;
        current_side = glancesBeforeMergeAdjacentScans(iScan).side;
        current_type = glancesBeforeMergeAdjacentScans(iScan).type;

        current_rate = (current_gaze(end)-current_gaze(1))/(current_time(end)-current_time(1));
        
        current_index = 1:new_scan_count;
        
        time_index = end_times <= current_time(1) & end_times > (current_time(1)-parameters(6));
        
        if length(current_index)~= length(end_times)
            keyboard
        end
                                        
        sign_index = sign(rate) == sign(current_rate);
        
        check_index = sign_index & time_index;
        
        % here, we only want to merge stuff on the same side. So, if we
        % have a bunch of candidate glances to merge and any of the middle
        % ones happen to be on the other side, we don't want to merge over
        % the zero line
        try
            side_check_index = side==current_side;
        catch
            keyboard
        end
        
        check_index(1:max((find(side_check_index == 0)))) = 0;
        
        if sign(current_rate) == current_side
            % on the left side and heading left
            % or on the right side and heading right
            % thus, only for away glances
            size_check1 = abs(start_gaze) < abs(current_gaze(1));
            size_check2 = abs(end_gaze) < abs(current_gaze(end));
        elseif  sign(current_rate) ~= current_side
            % on the left side and heading right
            % or on the right side and heading left
            % thus, only for return glances
            size_check1 = abs(start_gaze) > abs(current_gaze(1));
            size_check2 = abs(end_gaze) > abs(current_gaze(end));
        end
        
        check_index = check_index & size_check1 & size_check2;
        
        if any(check_index) %&& rate_check && start_check
            
            start_scan_list = current_index(min(find(check_index)):end);
            
            end_scan = iScan;
            
            for j = [start_scan_list end_scan]
                if j == min([start_scan_list end_scan])
                    try
                        temp_gaze = new_gaze_scans(j).gaze;
                    catch
                        keyboard
                    end
                    temp_time = new_gaze_scans(j).time;
                elseif j == end_scan
                    temp_gaze = [temp_gaze current_gaze];
                    temp_time = [temp_time current_time];
                else
                    try
                        temp_gaze = [temp_gaze new_gaze_scans(j).gaze];
                    catch
                        keyboard
                    end
                    temp_time = [temp_time new_gaze_scans(j).time];
                end
            end
            
            
            new_gaze_scans(min(start_scan_list)).gaze = temp_gaze;
            new_gaze_scans(min(start_scan_list)).time = temp_time;
            new_gaze_scans(min(start_scan_list)).side = current_side;
            new_gaze_scans(min(start_scan_list)).type = 'M';
            
            temp_rate = (temp_gaze(end)-temp_gaze(1))/(temp_time(end)-temp_time(1));
            
            start_times(min(start_scan_list)) = temp_time(1);
            end_times(min(start_scan_list)) = temp_time(end);
            
            start_gaze(min(start_scan_list)) = temp_gaze(1);
            end_gaze(min(start_scan_list)) = temp_gaze(end);
            
            rate(min(start_scan_list)) = temp_rate;
            side(min(start_scan_list)) = unique(sign(temp_gaze));
            
            type(min(start_scan_list)) = 'M';
            
            start_times((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            end_times((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            
            start_gaze((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            end_gaze((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            
            rate((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            side((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            type((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            
            new_gaze_scans((min(start_scan_list)+1):size(new_gaze_scans,2)) = [];
            
            new_scan_count = size(new_gaze_scans,2);
            
            continue
        end
        
        % if we aren't merging them, increase the count and add this
        % one
        new_scan_count = new_scan_count + 1;
        
        new_gaze_scans(new_scan_count).gaze = current_gaze;
        new_gaze_scans(new_scan_count).time = current_time;
        new_gaze_scans(new_scan_count).side = current_side;
        new_gaze_scans(new_scan_count).type = current_type;
        
        current_rate = (current_gaze(end)-current_gaze(1))/(current_time(end)-current_time(1));
        
        start_times(new_scan_count) = current_time(1);
        end_times(new_scan_count) = current_time(end);
        
        start_gaze(new_scan_count) = current_gaze(1);
        end_gaze(new_scan_count) = current_gaze(end);
        
        rate(new_scan_count) = current_rate;
        type(new_scan_count) = current_type;
        
        nanindex = isnan(current_gaze);
        if sum(nanindex)==length(current_gaze)
            % all nans? This is unusual.
            side(new_scan_count) = 0;
        else
            side(new_scan_count) = unique(sign(current_gaze(~nanindex)));
        end
    end
    
    test_count_thing(loop_count) = new_scan_count;
    
    if loop_count > 1
        diff_test_count_thing = diff(test_count_thing);
        
        if diff_test_count_thing(end)==0
            good_to_go_count = 10;
        end
    end
    
    if loop_count >= 9
        %   the WHILE statement at the top of the loop has the check on
        %   loop_count
        display('LOOP COUNT in constructGlances>99 skipping to next event'); %skip to next one.
    end
end


gaze_scans = new_gaze_scans;

for i = 1:length(gaze_scans)
    
    count = 0;
    
    for j = 1:length(gaze_movements)
        
        if gaze_movements(j).time(1) >= gaze_scans(i).time(1) && ...
                gaze_movements(j).time(end) <= gaze_scans(i).time(end)
            
            count = count + 1;
            
            temp_type(count) = gaze_movements(j).type;
            temp_index(count) = j;
            
            if sign(mean(diff(abs(gaze_movements(j).gaze)))) == 1 && gaze_movements(j).type == 's'
                temp_type(count) = 'A';
            elseif sign(mean(diff(abs(gaze_movements(j).gaze)))) == -1 && gaze_movements(j).type == 's'
                temp_type(count) = 'R';
            end
            
        elseif gaze_movements(j).time(1) > gaze_scans(i).time(end)
            break
        end
    end
    
    if count > 0
        temp_type(findstr(temp_type,'N')) = [];
        
        gaze_scans(i).type_expanded = temp_type;
        
        clear temp_type temp_index
    end
    
end


end