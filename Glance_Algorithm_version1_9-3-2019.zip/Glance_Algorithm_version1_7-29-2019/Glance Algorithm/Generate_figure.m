function Generate_figure(x,time,smoothHor,final_glances)

%    This file is part of Generate_figure.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Generate_figure.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019


Raw_gaze = x;
gaze = smoothHor;

gazeX_color = [0 0 1];


figure

hold on
line([time(1) time(end)],[0 0])
plot(time',Raw_gaze','Color',[0 0 0],'LineStyle','none','Marker','.')

ylim([-90 90]);
ylabel('Eccentricity (\circ)');
xlabel('Time from start of drive (s)');
set(gca,'Ydir','reverse')

xlim([time(1) time(end)])

set(gca,'ytick',[-90 -60 -30 0 30  60  90])

set(gca,'Color',[1 1 1])
set(gcf,'Color',[1 1 1])
set(gca,'FontSize',18)

set(gcf,'Position',[ -1311         288         904         393])

plot(time,gaze,'Color',gazeX_color,'LineWidth',3)

for i = 1:size(final_glances,2)
    
    x1 = final_glances(i).time(1);
    x2 = final_glances(i).time(end);
    y1 = final_glances(i).gaze(1);
    y2 = final_glances(i).gaze(end);
    
    
    if abs(y1) > abs(y2)
        %             line([x1 x2],...
        %                 [y1 y2],...
        %                 'LineWidth',3,'Color',[1 1 0])
        %
    elseif abs(y2) > abs(y1)
        
        if abs(y2)-abs(y1) > 4
            line([x1 x2],...
                [y1 y2],...
                'LineWidth',4,'Color',[0 1 0])
        end
    end
end

end

