function Glance_algorithm(filename,parameters,plot_data,save_data)

%    This file is part of Glance_algorithm.
%
%    Storage is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%    (at your option) any later version.
%
%    Storage is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with Glance_algorithm.  If not, see
%    <http://www.gnu.org/licenses/>.
%
%    If you use this code, please reference:
%
%    Swan, Goldstein, Savage, Ahmadi, & Bowers, Automatic Processing of Eye
%    and Head Movements to Quantify Gaze Scanning Behaviors in a Driving
%    Simulator 
%
%    Coded by: Garrett Swan
%    Date: 07/25/2019


%% load data
load(filename)

%% interpolate over zeros
nanx = isnan(x);
fuu    = 1:numel(x);
x(nanx) = interp1(fuu(~nanx), x(~nanx), fuu(nanx));
y(nanx) = interp1(fuu(~nanx), y(~nanx), fuu(nanx));
interpolatedHorizontalWithoutOutliers = x;
interpolatedVerticalWithoutOutliers = y;

%% filter data
k = parameters(1);
f = parameters(2);

smoothHor = sgolayfilt(interpolatedHorizontalWithoutOutliers,k,f);
smoothVer = sgolayfilt(interpolatedVerticalWithoutOutliers,k,f);

%% Find Saccades
gaze_movements = Gaze_saccade_categorization(smoothHor,smoothVer,t,parameters);

%% Find Gaze Scans
gaze_scans = Merging_gaze_saccades(gaze_movements,parameters);

%% Plot the data
if plot_data
    Generate_figure(x,t,smoothHor,gaze_scans);
end

%% Save the data
if save_data
    
   count = 0;
   for i = 1:length(gaze_scans)
      
       if abs(gaze_scans(i).gaze(end))-abs(gaze_scans(i).gaze(1)) > 4
           
           count = count + 1;
           
           start_time(count) = gaze_scans(i).time(1);
           end_time(count) = gaze_scans(i).time(end);
           duration(count) = end_time(count)-start_time(count);
        
           start_ecc(count) = gaze_scans(i).gaze(1);
           end_ecc(count) = gaze_scans(i).gaze(end);
           magnitude(count) = end_ecc(count)-start_ecc(count);
           
           glance_marking(count) = 1;
           marking(count) = 0;
       end
   end
   
   tbl = table(start_time',end_time',duration',start_ecc',end_ecc',magnitude',glance_marking',marking',...
       'VariableNames',{'start_time';'end_time';'duration';'start_ecc';'end_ecc';'magnitude';'glance_marking';'marking'});
   
   writetable(tbl,[filename '.xlsx']);
   
end

end